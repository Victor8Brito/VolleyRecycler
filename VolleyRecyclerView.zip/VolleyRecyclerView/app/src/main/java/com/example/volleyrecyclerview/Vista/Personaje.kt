package com.example.volleyrecyclerview.Vista

data class Personaje(val nombre:String, val imagen:String)
